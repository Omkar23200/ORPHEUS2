# ORPHEUS v0.7 — Interaction specification

## Response modes
1. Chat only — text replies, no spoken response.
2. Voice only — speak the answer, optional minimal on-screen transcript.
3. Chat + voice — transcript plus spoken response.

The selected mode must be user-controlled and persisted locally.

## Fun mode
When enabled, ORPHEUS may add an occasional short joke or playful line for casual/fun searches.
It must not interfere with navigation, safety, factual, or urgent requests.

## Speed
- Keep UI operations on the main thread.
- Show immediate feedback before network work.
- Cache repeatable/local results where appropriate.
- Do not request microphone or location continuously.
