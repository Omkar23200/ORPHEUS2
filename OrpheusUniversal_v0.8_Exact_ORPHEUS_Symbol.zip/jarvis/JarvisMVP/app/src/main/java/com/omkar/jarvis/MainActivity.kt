package com.omkar.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Popup
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import java.security.MessageDigest
import java.util.Locale

private const val PREFS = "orpheus_secure"
private const val PIN_KEY = "pin_hash"
private const val ENABLED_KEY = "enabled"
private const val SMART_POPUPS_KEY = "smart_popups"

// ORPHEUS v0.7: fast response + Chat/Voice/Both modes.
// Preference keys are intentionally local-only.
private const val PREF_RESPONSE_MODE = "response_mode" // CHAT, VOICE, BOTH
private const val PREF_FUN_MODE = "fun_mode"

private fun responseModeLabel(mode: String): String = when (mode) {
    "VOICE" -> "Voice only"
    "BOTH" -> "Chat + voice"
    else -> "Chat only"
}


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OrpheusApp() }
    }
}

private fun hashPin(pin: String): String =
    MessageDigest.getInstance("SHA-256")
        .digest(pin.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

private fun openMaps(context: Context, query: String) {
    val encoded = Uri.encode(query)
    val geoIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$encoded"))
    val browserIntent = Intent(
        Intent.ACTION_VIEW,
        Uri.parse("https://www.google.com/maps/search/?api=1&query=$encoded")
    )

    runCatching {
        if (geoIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(geoIntent)
        } else if (browserIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(browserIntent)
        }
    }
}



private fun openSmsComposer(context: Context, body: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("smsto:")
        putExtra("sms_body", body)
    }
    if (intent.resolveActivity(context.packageManager) != null) {
        context.startActivity(intent)
    } else {
        Toast.makeText(context, "No SMS app is available on this phone.", Toast.LENGTH_SHORT).show()
    }
}

private fun grammarCheck(text: String): String {
    var t = text.trim().replace(Regex("\\s+"), " ")
    if (t.isBlank()) return "Type or dictate some text first."
    val suggestions = mutableListOf<String>()
    if (t.first().isLowerCase()) {
        t = t.replaceFirstChar { it.uppercaseChar() }
        suggestions += "Capitalized the first word."
    }
    if (t.last() !in ".!?" && !t.endsWith(":")) {
        t += "."
        suggestions += "Added punctuation at the end."
    }
    val replacements = listOf(
        " i " to " I ",
        " dont " to " don't ",
        " doesnt " to " doesn't ",
        " cant " to " can't ",
        " wont " to " won't ",
        " im " to " I'm ",
        " ive " to " I've ",
        " youre " to " you're ",
        " its " to " it's "
    )
    var fixed = " $t "
    for ((from, to) in replacements) {
        if (fixed.contains(from, ignoreCase = true)) {
            fixed = fixed.replace(from, to, ignoreCase = true)
            suggestions += "Corrected common spelling/grammar."
        }
    }
    t = fixed.trim().replace(Regex("\\s+"), " ")
    return if (suggestions.isEmpty()) {
        "✓ No obvious spelling or grammar problems found.\n\n$t"
    } else {
        "ORPHEUS corrected it:\n$t\n\n• " + suggestions.distinct().joinToString("\n• ")
    }
}

private fun adviceFor(text: String): String {
    val q = text.lowercase(Locale.getDefault())
    return when {
        q.contains("study") || q.contains("exam") || q.contains("college") ->
            "Study advice: break the task into 25–45 minute sessions, practice problems instead of only reading, and keep a short list of weak topics to review."
        q.contains("job") || q.contains("career") || q.contains("mechanical") ->
            "Career advice: build one practical skill deeply, create 2–3 projects that prove it, and start applying for internships before graduation."
        q.contains("travel") || q.contains("trip") || q.contains("visit") ->
            "Travel advice: check distance, opening hours, local transport, reviews, weather, and a backup option before leaving."
        q.contains("message") || q.contains("text") || q.contains("friend") ->
            "Message advice: keep it clear, say what you need, use a polite tone, and avoid sending sensitive information unnecessarily."
        q.contains("buy") || q.contains("phone") || q.contains("laptop") ->
            "Buying advice: compare total cost, warranty, important specifications, and long-term software/support before choosing."
        else ->
            "Tell ORPHEUS what decision you are considering and your main constraints. I can organize the options, questions to check, and practical next steps."
    }
}

private data class DiscoveryPlace(
    val name: String,
    val category: String,
    val detail: String
)

private fun discoveryFor(query: String): Pair<String, List<DiscoveryPlace>> {
    val q = query.lowercase(Locale.getDefault())
    val city = when {
        q.contains("mysuru") || q.contains("mysore") -> "Mysuru"
        q.contains("vijayapura") || q.contains("bijapur") -> "Vijayapura"
        q.contains("bengaluru") || q.contains("bangalore") -> "Bengaluru"
        q.contains("mumbai") -> "Mumbai"
        q.contains("delhi") || q.contains("new delhi") -> "Delhi"
        q.contains("hyderabad") -> "Hyderabad"
        q.contains("goa") -> "Goa"
        q.contains("pune") -> "Pune"
        q.contains("jaipur") -> "Jaipur"
        q.contains("agra") -> "Agra"
        else -> query.trim().ifBlank { "This place" }
    }

    val places = when (city) {
        "Mysuru" -> listOf(
            DiscoveryPlace("Mysore Palace", "Monument", "Historic royal palace and major city landmark."),
            DiscoveryPlace("Chamundeshwari Temple", "Heritage", "Hilltop temple and cultural landmark."),
            DiscoveryPlace("Jaganmohan Palace", "Culture", "Historic palace known for its art collection."),
            DiscoveryPlace("Brindavan Gardens", "Nature", "Famous landscaped gardens near the Krishna Raja Sagara dam.")
        )
        "Vijayapura" -> listOf(
            DiscoveryPlace("Gol Gumbaz", "Monument", "Iconic Deccan-era mausoleum with a massive dome."),
            DiscoveryPlace("Ibrahim Rauza", "Monument", "Historic tomb-and-mosque complex known for its architecture."),
            DiscoveryPlace("Bara Kaman", "Heritage", "Unfinished 17th-century monument complex."),
            DiscoveryPlace("Jod Gumbaz", "Heritage", "Historic twin-domed tomb complex.")
        )
        "Bengaluru" -> listOf(
            DiscoveryPlace("Bangalore Palace", "Monument", "Historic palace and major Bengaluru landmark."),
            DiscoveryPlace("Vidhana Soudha", "Architecture", "Iconic government building with distinctive architecture."),
            DiscoveryPlace("Lalbagh Botanical Garden", "Nature", "Large historic botanical garden."),
            DiscoveryPlace("Cubbon Park", "Nature", "Major green space in central Bengaluru.")
        )
        "Mumbai" -> listOf(
            DiscoveryPlace("Gateway of India", "Monument", "Waterfront landmark overlooking the Arabian Sea."),
            DiscoveryPlace("Chhatrapati Shivaji Maharaj Terminus", "Heritage", "Historic railway terminus and UNESCO World Heritage Site."),
            DiscoveryPlace("Elephanta Caves", "Heritage", "Rock-cut cave temples on Elephanta Island."),
            DiscoveryPlace("Marine Drive", "Scenic", "Famous waterfront promenade and city viewpoint.")
        )
        "Delhi" -> listOf(
            DiscoveryPlace("India Gate", "Monument", "War memorial and major New Delhi landmark."),
            DiscoveryPlace("Red Fort", "Heritage", "Historic Mughal-era fort complex."),
            DiscoveryPlace("Qutub Minar", "Monument", "Historic minaret and UNESCO World Heritage Site."),
            DiscoveryPlace("Humayun's Tomb", "Heritage", "Historic Mughal garden-tomb complex.")
        )
        "Hyderabad" -> listOf(
            DiscoveryPlace("Charminar", "Monument", "Iconic historic monument in the old city."),
            DiscoveryPlace("Golconda Fort", "Heritage", "Historic fort complex with major Deccan history."),
            DiscoveryPlace("Chowmahalla Palace", "Culture", "Historic palace complex."),
            DiscoveryPlace("Hussain Sagar", "Scenic", "Large lake and central city landmark.")
        )
        "Goa" -> listOf(
            DiscoveryPlace("Basilica of Bom Jesus", "Heritage", "Historic church in Old Goa."),
            DiscoveryPlace("Fort Aguada", "Monument", "Historic coastal fort and lighthouse area."),
            DiscoveryPlace("Se Cathedral", "Heritage", "Historic cathedral in Old Goa."),
            DiscoveryPlace("Baga Beach", "Nature", "Popular beach and coastal destination.")
        )
        "Pune" -> listOf(
            DiscoveryPlace("Shaniwar Wada", "Monument", "Historic fortification and major Pune landmark."),
            DiscoveryPlace("Aga Khan Palace", "Heritage", "Historic palace with important modern Indian history."),
            DiscoveryPlace("Sinhagad Fort", "Nature", "Historic hill fort near Pune."),
            DiscoveryPlace("Pataleshwar Cave Temple", "Heritage", "Rock-cut cave temple in the city.")
        )
        "Jaipur" -> listOf(
            DiscoveryPlace("Amber Fort", "Monument", "Historic hill fort and palace complex."),
            DiscoveryPlace("Hawa Mahal", "Architecture", "Famous historic palace facade."),
            DiscoveryPlace("City Palace", "Culture", "Historic royal palace complex."),
            DiscoveryPlace("Jantar Mantar", "Science", "Historic astronomical observation site.")
        )
        "Agra" -> listOf(
            DiscoveryPlace("Taj Mahal", "Monument", "Famous Mughal-era mausoleum and UNESCO World Heritage Site."),
            DiscoveryPlace("Agra Fort", "Heritage", "Historic Mughal fort complex."),
            DiscoveryPlace("Itmad-ud-Daulah's Tomb", "Heritage", "Historic Mughal tomb often noted for its marble work."),
            DiscoveryPlace("Mehtab Bagh", "Scenic", "Garden with views toward the Taj Mahal.")
        )
        else -> emptyList()
    }
    return city to places
}

private fun localOrpheusAnswer(input: String): String {
    val q = input.lowercase(Locale.getDefault())
    return when {
        q.contains("restaurant") || q.contains("dinner") || q.contains("food") || q.contains("eat") ->
            "I can open your map app and search for restaurants nearby."
        q.contains("coffee") || q.contains("cafe") ->
            "I can open your map app and search for nearby cafés."
        q.contains("weather") ->
            "Live weather needs a weather data source. This local-first build does not track your location continuously."
        q.contains("map") || q.contains("location") || q.contains("near me") ->
            "I can open your map app for that search."
        q.contains("who are you") ->
            "I am ORPHEUS, your local-first assistant."
        q.contains("privacy") ->
            "PIN and settings stay on this device. Chat messages are not saved after the app closes."
        else ->
            "I heard you. This build handles local commands without requiring an AI API key."
    }
}

@Composable
fun OrpheusApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var pinHash by remember { mutableStateOf(prefs.getString(PIN_KEY, null)) }
    var unlocked by remember { mutableStateOf(pinHash == null) }
    var pin by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(prefs.getBoolean(ENABLED_KEY, true)) }
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(listOf("ORPHEUS: Online. Local-first privacy mode is active.")) }
    var discoveryEnabled by remember { mutableStateOf(true) }
    var discoveryPlace by remember { mutableStateOf<String?>(null) }
    var discoveryItems by remember { mutableStateOf(emptyList<DiscoveryPlace>()) }
    var assistResult by remember { mutableStateOf<String?>(null) }
    var smartPopups by remember { mutableStateOf(prefs.getBoolean(SMART_POPUPS_KEY, true)) }
    var smartNote by remember { mutableStateOf<String?>(null) }
    var pendingMapQuery by remember { mutableStateOf<String?>(null) }

    val speechPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) listening = true
    }

    fun ask(text: String) {
        if (text.isBlank() || !enabled) return
        val clean = text.trim()
        val lower = clean.lowercase(Locale.getDefault())
        if (smartPopups) {
            smartNote = when {
                lower.contains("restaurant") || lower.contains("dinner") || lower.contains("food") || lower.contains("eat") -> "I can help you find food nearby. Tap Dinner or Ask to search maps."
                lower.contains("monument") || lower.contains("tourist") || lower.contains("visit") || lower.contains("place") || lower.contains("city") -> "ORPHEUS Discovery can point out notable monuments, culture and nature spots."
                lower.startsWith("check grammar") || lower.startsWith("correct grammar") || lower.startsWith("fix grammar") -> "I can check spelling, grammar and punctuation before you send it."
                lower.startsWith("advice") || lower.startsWith("advise") -> "Tell me the situation and I’ll organize practical advice."
                lower.startsWith("message") || lower.startsWith("sms") || lower.startsWith("send message") -> "I can prepare the message and open your SMS app. You still choose the recipient and send it."
                lower.contains("map") || lower.contains("location") || lower.contains("near me") -> "I can open your map app and add an ORPHEUS discovery note."
                else -> "ORPHEUS is ready. I can help with places, messages, grammar, advice and more."
            }
        }
        if (discoveryEnabled && !lower.contains("restaurant") && !lower.contains("dinner") && !lower.contains("food") && !lower.contains("eat") && !lower.contains("coffee") && !lower.contains("cafe")) {
            val result = discoveryFor(clean)
            discoveryPlace = result.first
            discoveryItems = result.second
        }
        messages = messages + "You: $clean" + "ORPHEUS: ${localOrpheusAnswer(clean)}"

        when {
            lower.startsWith("check grammar") || lower.startsWith("correct grammar") || lower.startsWith("fix grammar") -> {
                val source = clean.substringAfter(Regex("(?i)check grammar|correct grammar|fix grammar"), "").trim()
                assistResult = grammarCheck(source)
            }
            lower.startsWith("advice") || lower.startsWith("advise") -> {
                val source = clean.substringAfter(Regex("(?i)advice|advise"), "").trim()
                assistResult = adviceFor(source)
            }
            lower.startsWith("message") || lower.startsWith("sms") || lower.startsWith("send message") -> {
                val source = clean.substringAfter(Regex("(?i)send message|message|sms"), "").trim()
                val body = if (source.isBlank()) "" else grammarCheck(source).substringAfter("ORPHEUS corrected it:\n").substringBefore("\n\n•")
                openSmsComposer(context, body)
            }
            lower.contains("restaurant") || lower.contains("dinner") || lower.contains("food") || lower.contains("eat") ->
                if (smartPopups) { pendingMapQuery = "restaurants near me" } else openMaps(context, "restaurants near me")
            lower.contains("coffee") || lower.contains("cafe") ->
                if (smartPopups) { pendingMapQuery = "cafes near me" } else openMaps(context, "cafes near me")
            lower.contains("map") || lower.contains("location") ->
                if (smartPopups) { pendingMapQuery = clean } else openMaps(context, clean)
        }
        input = ""
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(WindowInsets.safeDrawing.asPaddingValues())
    ) {
        Box(Modifier.fillMaxSize()) {
        when {
            !unlocked -> {
                PinScreen(
                    title = "ORPHEUS locked",
                    subtitle = "Enter your PIN to access ORPHEUS",
                    pin = pin,
                    onPin = { pin = it },
                    onSubmit = {
                        if (pinHash != null && pinHash == hashPin(pin)) {
                            unlocked = true
                            pin = ""
                        }
                    }
                )
            }
            pinHash == null -> {
                PinScreen(
                    title = "Create your ORPHEUS PIN",
                    subtitle = "Use at least 4 digits. The PIN is stored only as a hash.",
                    pin = pin,
                    onPin = { pin = it },
                    onSubmit = {
                        if (pin.length >= 4 && pin.all(Char::isDigit)) {
                            pinHash = hashPin(pin)
                            prefs.edit().putString(PIN_KEY, pinHash).apply()
                            pin = ""
                        }
                    }
                )
            }
            else -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .imePadding()
                        .navigationBarsPadding()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(R.drawable.orpheus_logo),
                                contentDescription = "ORPHEUS logo",
                                modifier = Modifier.size(64.dp),
                                contentScale = ContentScale.Fit
                            )
                            Spacer(Modifier.size(10.dp))
                            Column {
                                Text("ORPHEUS", style = MaterialTheme.typography.headlineSmall)
                                Text("Local-first intelligence")
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (enabled) "ON" else "OFF")
                            Switch(
                                checked = enabled,
                                onCheckedChange = {
                                    enabled = it
                                    prefs.edit().putBoolean(ENABLED_KEY, it).apply()
                                }
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { showSettings = true }) { Text("Privacy & Settings") }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Discovery")
                            Switch(checked = discoveryEnabled, onCheckedChange = { discoveryEnabled = it })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Popups")
                            Switch(
                                checked = smartPopups,
                                onCheckedChange = {
                                    smartPopups = it
                                    if (!it) smartNote = null
                                    prefs.edit().putBoolean(SMART_POPUPS_KEY, it).apply()
                                }
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))

                    if (assistResult != null) {
                        AssistPanel(
                            result = assistResult!!,
                            onDismiss = { assistResult = null },
                            onSend = { openSmsComposer(context, assistResult!!.substringAfter("ORPHEUS corrected it:\n").substringBefore("\n\n•").trim()) }
                        )
                        Spacer(Modifier.height(8.dp))
                    }

                    if (discoveryEnabled && discoveryPlace != null) {
                        DiscoveryPanel(
                            place = discoveryPlace!!,
                            items = discoveryItems,
                            onSearchCategory = { category -> openMaps(context, "$category in ${discoveryPlace}") },
                            onOpenPlace = { name -> openMaps(context, "$name, ${discoveryPlace}") }
                        )
                        Spacer(Modifier.height(8.dp))
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(messages) { message -> Text(message) }
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(enabled = enabled && input.isNotBlank(), onClick = { assistResult = grammarCheck(input) }, modifier = Modifier.weight(1f)) { Text("Grammar") }
                        OutlinedButton(enabled = enabled && input.isNotBlank(), onClick = { assistResult = adviceFor(input) }, modifier = Modifier.weight(1f)) { Text("Advice") }
                        OutlinedButton(enabled = enabled && input.isNotBlank(), onClick = { openSmsComposer(context, input) }, modifier = Modifier.weight(1f)) { Text("Message") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        enabled = enabled,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Ask ORPHEUS…") },
                        singleLine = false,
                        maxLines = 3
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            enabled = enabled && input.isNotBlank(),
                            onClick = { ask(input) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Ask") }
                        OutlinedButton(
                            enabled = enabled,
                            onClick = {
                                if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                    speechPermission.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    listening = true
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(if (listening) "Listening…" else "Voice") }
                        OutlinedButton(
                            enabled = enabled,
                            onClick = { openMaps(context, "restaurants near me") },
                            modifier = Modifier.weight(1f)
                        ) { Text("Dinner") }
                    }

                    if (listening) {
                        SpeechCapture(
                            onResult = { text -> listening = false; ask(text) },
                            onError = { listening = false }
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "No chat history is saved. No continuous location tracking.",
                        style = MaterialTheme.typography.bodySmall
                    )

                }
            }
        }

        if (smartPopups && smartNote != null && unlocked && enabled) {
            Popup(
                alignment = Alignment.BottomEnd,
                onDismissRequest = { smartNote = null }
            ) {
                SmartPopup(
                    note = smartNote!!,
                    actionLabel = if (pendingMapQuery != null) "Open Maps" else null,
                    onAction = if (pendingMapQuery != null) {
                        {
                            val query = pendingMapQuery
                            pendingMapQuery = null
                            smartNote = null
                            if (query != null) openMaps(context, query)
                        }
                    } else null,
                    onDismiss = { smartNote = null; pendingMapQuery = null },
                    onDisable = {
                        smartPopups = false
                        smartNote = null
                        pendingMapQuery = null
                        prefs.edit().putBoolean(SMART_POPUPS_KEY, false).apply()
                    }
                )
            }
        }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("ORPHEUS privacy") },
            text = {
                Text(
                    "• PIN is stored as a SHA-256 hash.\n" +
                        "• Chat messages exist only in memory and disappear when the app closes.\n" +
                        "• No AI API key is embedded in this build.\n" +
                        "• Voice recognition uses the Android speech-recognition service after you press Voice.\n" +
                        "• Location is not continuously tracked.\n" +
                        "• Maps searches leave the phone when you choose to open a map/search service."
                )
            },
            confirmButton = {
                TextButton(onClick = { showSettings = false }) { Text("Close") }
            },
            dismissButton = {
                TextButton(onClick = {
                    unlocked = false
                    showSettings = false
                }) { Text("Lock now") }
            }
        )
    }
}


@Composable
private fun SmartPopup(
    note: String,
    actionLabel: String?,
    onAction: (() -> Unit)?,
    onDismiss: () -> Unit,
    onDisable: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.orpheus_logo),
                contentDescription = "ORPHEUS popup",
                modifier = Modifier.size(42.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("ORPHEUS", style = MaterialTheme.typography.titleSmall)
                Text(note, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDismiss) { Text("×") }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 58.dp, end = 10.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (actionLabel != null && onAction != null) {
                Button(onClick = onAction) { Text(actionLabel) }
            }
            TextButton(onClick = onDisable) { Text("Turn off popups") }
        }
    }
}

@Composable
private fun AssistPanel(
    result: String,
    onDismiss: () -> Unit,
    onSend: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.orpheus_logo),
                    contentDescription = "ORPHEUS Assist symbol",
                    modifier = Modifier.size(38.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("ORPHEUS ASSIST", style = MaterialTheme.typography.titleMedium)
                    Text("Grammar • Advice • Messages", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(result)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDismiss) { Text("Close") }
                if (result.contains("ORPHEUS corrected it:")) {
                    Button(onClick = onSend) { Text("Use in Message") }
                }
            }
        }
    }
}

@Composable
private fun DiscoveryPanel(
    place: String,
    items: List<DiscoveryPlace>,
    onSearchCategory: (String) -> Unit,
    onOpenPlace: (String) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.orpheus_logo),
                    contentDescription = "ORPHEUS Discovery symbol",
                    modifier = Modifier.size(38.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("ORPHEUS DISCOVERY", style = MaterialTheme.typography.titleMedium)
                    Text("Notable places in $place", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (items.isEmpty()) {
                Text("I don't have a built-in landmark list for this place yet. Choose a category to search it on your map.")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Monuments", "Museums", "Nature").forEach { category ->
                        OutlinedButton(onClick = { onSearchCategory(category) }) { Text(category) }
                    }
                }
            } else {
                items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(R.drawable.orpheus_logo),
                            contentDescription = null,
                            modifier = Modifier.size(28.dp),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.name, style = MaterialTheme.typography.titleSmall)
                            Text("${item.category} • ${item.detail}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { onOpenPlace(item.name) }) { Text("Map") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PinScreen(
    title: String,
    subtitle: String,
    pin: String,
    onPin: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.orpheus_logo),
            contentDescription = "ORPHEUS logo",
            modifier = Modifier.size(190.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        Text(subtitle)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { value ->
                if (value.length <= 12 && value.all(Char::isDigit)) onPin(value)
            },
            label = { Text("PIN") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onSubmit,
            enabled = pin.length >= 4,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Continue") }
    }
}

@Composable
private fun SpeechCapture(onResult: (String) -> Unit, onError: () -> Unit) {
    val context = LocalContext.current

    DisposableEffect(Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError()
            return@DisposableEffect onDispose { }
        }

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text.isNullOrBlank()) onError() else onResult(text)
            }
            override fun onError(error: Int) = onError()
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        recognizer.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
        )

        onDispose { recognizer.destroy() }
    }
}


/** Local response preferences used by the ORPHEUS UI. */
private fun saveResponseMode(mode: String) {
    getSharedPreferences("orpheus_settings", MODE_PRIVATE)
        .edit().putString(PREF_RESPONSE_MODE, mode).apply()
}

private fun loadResponseMode(): String =
    getSharedPreferences("orpheus_settings", MODE_PRIVATE)
        .getString(PREF_RESPONSE_MODE, "CHAT") ?: "CHAT"

private fun isFunModeEnabled(): Boolean =
    getSharedPreferences("orpheus_settings", MODE_PRIVATE)
        .getBoolean(PREF_FUN_MODE, true)

private fun setFunModeEnabled(enabled: Boolean) {
    getSharedPreferences("orpheus_settings", MODE_PRIVATE)
        .edit().putBoolean(PREF_FUN_MODE, enabled).apply()
}
