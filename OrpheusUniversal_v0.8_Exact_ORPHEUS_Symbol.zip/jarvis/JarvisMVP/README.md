# ORPHEUS Universal v0.6 – Smart Popups

Android Studio project for the ORPHEUS local-first assistant.

## Highlights
- Android 6.0+ target strategy for broad compatibility
- ORPHEUS logo and futuristic assistant UI
- PIN lock and master ON/OFF control
- Discovery mode for notable places
- Grammar/spelling assistant
- Advice assistant
- SMS composer helper
- Voice input
- Smart ORPHEUS popup: a small logo-led note appears after relevant searches/actions
- Smart Popups can be turned off in the app
- For map searches, the popup can offer **Open Maps** rather than silently launching Maps
- No continuous location tracking
- No API key embedded in the APK source

## Build
Open `JarvisMVP` in Android Studio and build a debug APK with:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**

The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.


## ORPHEUS v0.7 — Fast Voice + Chat
- Response mode: **Chat only**, **Voice only**, or **Chat + voice**.
- Mode is saved locally on the phone and can be changed at any time.
- **Fun Mode** can add occasional light jokes/playful responses for casual searches; it can be disabled.
- Search/action UI is designed for fast local interaction first, with network searches only when needed.
- Voice should be started only when requested; no continuous listening is required.
- Heavy work should run off the main UI thread so the interface stays responsive.
- The app should show a short immediate status ("Searching…"/"Thinking…") before results arrive.
