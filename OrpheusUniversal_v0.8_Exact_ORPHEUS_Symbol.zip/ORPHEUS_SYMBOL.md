The canonical ORPHEUS symbol is the user's supplied reference artwork. Do not substitute a redesigned emblem. The drawable-nodpi/orpheus_logo.png asset is the source used by the app UI.
